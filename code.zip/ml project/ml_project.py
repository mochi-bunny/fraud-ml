import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import streamlit as st


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.svm import SVC
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import StackingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split 
import xgboost as xgb

# load data
df = pd.read_csv(r"C:\Users\manoj\Downloads\creditcard.csv")

# separate legitimate and fraudulent transactions
legit=df[df.Class==0]
fraud=df[df.Class==1]
legit_data=legit.sample(n=492)
df2=pd.concat([legit_data,fraud], axis=0)
X=df2.drop(columns='Class',axis=1)
Y=df2['Class'] 

X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=42)


 


lr= LogisticRegression(solver='lbfgs', max_iter=1000)
svm = SVC(gamma = 'auto', kernel = 'linear', decision_function_shape='ovo')
xg = xgb.XGBClassifier(objective= 'binary:logistic', n_estimators = 10, seed= 123)

estimators= [('svm', svm), ('logreg', lr)]
 
stack = StackingClassifier(estimators=estimators, final_estimator=xg)
stack.fit(X_train,Y_train)

#pred= stack.predict(X_test)

b_type = ["fraud","legit"]

pred = stack.predict(X_train)

# evaluate model performance
 
# create Streamlit app
st.title("Credit Card Fraud Detection Model")
st.write("Enter the following features to check if the transaction is legitimate or fraudulent:")

# create input fields for user to enter feature values
input_df = st.text_input('Input All features')
input_df_lst = input_df.split(',')
# create a button to submit input and get prediction
submit = st.button("Submit")

if submit:
    # get input feature values
    features = np.array(input_df_lst, dtype=np.float64)
    # make prediction
    prediction = stack.predict(features.reshape(1,-1))
    # display result
    if prediction[0] == 0:
        st.write("Legitimate transaction")
    else:
        st.write("Fraudulent transaction")
